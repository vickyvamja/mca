//find median for discrete ungrouped data
#include<stdio.h>
int main()
{
	int a;
	printf("\n enter the howmany data ? \n");
	scanf("%d",&a);
	int rec[a],fre[a];
	printf("\n observation :\n");
	for(int i=0;i<a;i++)
	{
		scanf("%d",&rec[i]);
	}
	for(int i=0;i<a-1;i++)
	{
		for(int j=i+1;j<a;j++)
		{
			if(rec[i]>rec[j])
			{
				int temp=rec[i];
				rec[i]=rec[j];
				rec[j]=temp;
			}
		}
	}
	int total=0;
	printf("\n frequency : \n");
	for(int i=0;i<a;i++)
	{
		scanf("%d",&fre[i]);
		total=total+fre[i];
	}
	int cf[a];
	int sum=0;
	printf("\n cummulative frequency : \n");
	for(int i=0;i<a;i++)
	{
		sum=sum+fre[i];		
		cf[i]=sum;
	}
	printf("\n observation         frequency       c.f\n");
	for(int i=0;i<a;i++)
	{
		printf("\n%d\t\t%d\t\t%d\n",rec[i],fre[i],cf[i]);
	}	
	printf("total :\t%d\n",total);
	float ans=(float)(total+1)/2;
	printf("\nmedian position = n+1/2\n");
	printf("median position = %d+1/2\n",total);
	printf("median position = %.1f\n",ans);
	int pos=0;
	for(int i=0;i<a;i++)
	{
		if(ans>=cf[i] && ans<=cf[i+1])
		{
			pos=i+1;	
		}				
	}
	printf("median is : %d\n",rec[pos]);
}
