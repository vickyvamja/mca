//find median for continuous grouped data
#include<stdio.h>
int main()
{
	int a;
	int inter;
	printf("\n enter the howmany data ? \n");
	scanf("%d",&a);
	int rec[a],rec2[a],fre[a];
	printf("\n enter the interval between two classes ? \n");
	scanf("%d",&inter);
	printf("\n lower limit of classes :\n");
	for(int i=0;i<a;i++)
	{
		scanf("%d",&rec[i]);
	}
	for(int i=0;i<a;i++)
	{
		rec2[i]=rec[i]+inter;
	}
	int total=0;
	printf("\n frequency : \n");
	for(int i=0;i<a;i++)
	{
		scanf("%d",&fre[i]);
		total=total+fre[i];
	}
	int cf[a];
	int sum=0;
	printf("\n cummulative frequency : \n");
	for(int i=0;i<a;i++)
	{
		sum=sum+fre[i];		
		cf[i]=sum;
	}
	printf("\n classes         frequency        c.f\n");
	for(int i=0;i<a;i++)
	{
		printf("\n%d-%d\t\t%d\t\t%d\n",rec[i],rec2[i],fre[i],cf[i]);
	}	
	printf("total :\t%d\n",total);
	float ans=(float)(total/2);
	printf("\nmedian position = n/2\n");
	printf("median position = %d/2\n",total);
	printf("median position = %.1f\n",ans);
	int pos=0;
	for(int i=0;i<a;i++)
	{
		if(ans>=cf[i] && ans<=cf[i+1])
		{
			pos=i+1;	
		}				
	}
	printf("xl is : %d\n",rec[pos]);
	printf("n/2 is :%.1f",ans);
	printf("f< is :%d",cf[pos-1]);
	printf("c is :%d",inter);
	printf("f is :%d",fre[pos]);
	
}
