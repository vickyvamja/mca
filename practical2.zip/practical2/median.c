//find median for ungrouped data
#include<stdio.h>
int main()
{
	int a;
	int counter;
	printf("\n enter the howmany data ? \n");
	scanf("%d",&a);
	int rec[a];
	printf("\n data :\n");
	for(int i=0;i<a;i++)
	{
		scanf("%d",&rec[i]);
	}
	for(int i=0;i<a-1;i++)
	{
		for(int j=i+1;j<a;j++)
		{
			if(rec[i]>rec[j])
			{
				int temp=rec[i];
				rec[i]=rec[j];
				rec[j]=temp;
			}
		}
	}
	printf("\n data is : \n");
	for(int i=0;i<a;i++)
	{
		printf("%d\t",rec[i]);
	}
	int ans;
	if(a%2==0)
	{
		ans=(a/2)+((counter/2)+1)/2;
	}
	else
	{
		ans=(a+1)/2;
	}
	printf("\n position of ith is : %d \n",ans);
	printf("\n median is : %d \n",rec[ans]);
}
