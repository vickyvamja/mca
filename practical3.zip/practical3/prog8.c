#include<stdio.h>
int sum(int);
int main()
{
	int n,s;
	printf("\n enter the N :");
	scanf("%d",&n);
	s=sum(n);
	printf("\n SUM : %d",s);
}
int sum(int n)
{
	int count;
	if(n==1)
	{
		return n;
	}
	else
	{
		for(int i=0;i<n;i++){
			 count++;}
		printf("\n TOTAL NUMBER : %d",count);
		return sum(n-1) + n;
	}
}
