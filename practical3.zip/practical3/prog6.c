#include<stdio.h>
int power(int);
int main()
{
	int n,p;
	printf("\n entre the N :\n");
	scanf("%d",&n);
	p=power(n);
	printf("\n power = %d\n",p);
}
int power(int n)
{
	if(n==)
	{
		return n;
	}
	else
	{
		return power(n)*n;
	}
}
