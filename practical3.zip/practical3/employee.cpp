#include<iostream>
using namespace std;
class Employee
{
	private:
		int empno;
		char name[25];
		float basicsalary;
		float monthlysalary;
		float salary;
		static float da_rate;
		static float hra_rate;
	public:
		void setemployee(int eno,char* na,float bs)
		{
			empno=eno;
			for(int i=0;i<25;i++)
				name[i]=na[i];
			basicsalary=bs;
		}
		static void setda_rate(const float d)
		{
			da_rate=d;
		}
		static void sethra_rate(const float hr)
		{
			hra_rate=hr;
		}
		void calc_monthlysalary()
		{
			int da,hra;
			da=(basicsalary*da_rate)/100;
			hra=(basicsalary*hra_rate)/100;
			monthlysalary=basicsalary+da+hra;
		}
		void show()
		{
			cout<<"emp no:"<<empno<<endl;
			cout<<"emp name:"<<name<<endl;
			cout<<"emp basicsalary:"<<basicsalary<<endl;
			cout<<"da rate is:"<<da_rate<<endl;
			cout<<"hra rate is:"<<hra_rate<<endl;
			cout<<"emp monthlysalary:"<<monthlysalary<<endl;
		}
	
};
float Employee::da_rate;
float Employee::hra_rate;
int main()
{
	Employee ram;
	ram.setemployee(12,"ram",1000);
	ram.setda_rate(50);
	ram.sethra_rate(10);
	ram.calc_monthlysalary();
	ram.show();
	
	Employee rahim;
	rahim.setemployee(12,"rahim",2000);
	rahim.setda_rate(50);
	rahim.sethra_rate(10);
	rahim.calc_monthlysalary();
	rahim.show();
	
	Employee joseph;
	rahim.setemployee(12,"joseph",3000);
	rahim.setda_rate(50);
	rahim.sethra_rate(10);
	rahim.calc_monthlysalary();
	rahim.show();	
}
