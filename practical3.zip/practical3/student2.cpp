
#include<iostream>
using namespace std;
class student
{
	private:
		static float passingmarks;
	public:
		static void setpassingmarks(const float marks)
		{
			passingmarks=marks;
		}
		static const void showpassingmarks()
		{
			cout<<"passing marks is:"<<passingmarks<<endl;
		}
		const static float getpassingmarks()
		{
			return passingmarks;
		}
	
};
float student::passingmarks;
int main()
{
	student ram;
	ram.setpassingmarks(18.45);
	ram.showpassingmarks();	
	cout<<"ram passing marks :"<<ram.getpassingmarks()<<endl;
	
	student rahim;
	rahim.setpassingmarks(30.12);
	rahim.showpassingmarks();
	cout<<"rahim passing marks :"<<rahim.getpassingmarks()<<endl;
	
	student joseph;
	joseph.setpassingmarks(24);
	joseph.showpassingmarks();
	cout<<"joseph passing marks :"<<joseph.getpassingmarks()<<endl;
}
