#include<stdio.h>
int factorial(int);
int main()
{
	int n;
	int f;
	printf("\n enter the n :\n");
	scanf("%d",&n);
	f=factorial(n);
	printf("\n FACT : %d \n",f);	
}
int factorial(int n)
{
	if(n==1)
		return n;
	else
		return factorial(n-1)*n;
}
