#include<stdio.h>
int fibonacci(int);
int main()
{
	int n;
	int f;
	printf("\n enter the n :\n");
	scanf("%d",&n);
	f=fibonacci(n);
	printf("\n series : %d\n",f);	
}
int fibonacci(int n)
{
	int n2=(n/2)-1;
	if(n==1)
	{
		return n;
	}
	else
	{
		n=n-n2;
		return fibonacci(n);
		n2--;
	}
}
