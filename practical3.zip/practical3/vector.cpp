#include<iostream>
using namespace std;
class vector
{
	private:
		int *p;
		int size;
	public:
		void setvector(int sz)
		{
			size=sz;
			p=new int(size);
			for(int i=0;i<size;i++)
				cin>>p[i];
		}
		void show()
		{
			for(int i=0;i<size;i++)
			{
				cout<<"["<<i<<"]"<<p[i]<<endl;
			}
		}
		friend void countoddnumber(); 
};
void countoddnumber()
{
	
}
int main()
{
	int size;
	cout<<"enter the size:"<<endl;
	cin>>size;
	vector v1;
	v1.setvector(size);
	v1.show();	
}
