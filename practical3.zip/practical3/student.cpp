#include<iostream>
using namespace std;
class student
{
	private:
		static char holiday[20];
	public:
		static void setholiday(char const day[20])
		{
			for(int i=0;i<20;i++)
					holiday[i]=day[i];
		}
		static void showholiday()
		{
			cout<<"holiday is :"<<holiday<<endl;
		}
		static const char* getholiday()
		{
			return holiday;	
		}
	
};
char student::holiday[20];
int main()
{
	student ram;
	ram.setholiday("sunday");
	ram.showholiday();
	cout<<"ram holiday is :"<<ram.getholiday()<<endl;
	
	student rahim;
	rahim.setholiday("monday");
	rahim.showholiday();
	cout<<"rahim holiday is :"<<rahim.getholiday()<<endl;
	
	student joseph;
	joseph.setholiday("saturday");
	joseph.showholiday();
	cout<<"joseph holiday is :"<<joseph.getholiday()<<endl;
}
