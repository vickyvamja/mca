#include<stdio.h>
int toh(int,char,char,char);
int main()
{
	int n;
	printf("\n enter disk N :\n");
	scanf("%d",&n);
	toh(n,'A','c','B');
	return 0;
}
int toh(int n,char s,char d,char p)
{
	if(n==1)
	{
		printf("\n move the disk  1 from %c to %c ",s,d);
		return;
	}
	toh(n-1,s,p,d);
	printf("\n move disk %d from %c to %c",n,s,d);
	toh(n-1,p,d,s);
	return;
}
